<?php

// Heading
$_['heading_title'] = 'ProBG AI Tools';

// Text
$_['text_extension'] = 'Разширения';
$_['text_success'] = 'Успешно променихте настройките на ProBG AI Tools!';
$_['text_edit'] = 'Настройки';
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Изключено';
$_['text_yes'] = 'Да';
$_['text_no'] = 'Не';

//Tabs
$_['tab_general']        = 'Основни настройки';
$_['tab_ai_sitemap']     = 'AI Sitemap';
$_['tab_llms']           = 'LLMS';
$_['tab_products_graph'] = 'Products Graph';
$_['tab_advanced']       = 'Разширени';

// Entry
$_['entry_status'] = 'Статус';
$_['entry_site_description'] = 'AI Description (LLMS.txt)';

$_['help_site_description'] = 'Кратко описание на магазина за AI модели. Ако е празно, ще се използва Meta Description на магазина.';

$_['entry_products'] = 'Продукти';

$_['entry_categories'] = 'Категории';

$_['entry_brands'] = 'Марки';

$_['entry_product_limit'] = 'Лимит на продуктите';

$_['entry_ai_sitemap']   = 'AI Sitemap';
$_['entry_urls']         = 'URL адреси';
$_['entry_htaccess']     = '.htaccess правила';

$_['entry_ai_sitemap_url'] = 'AI Sitemap URL';

$_['entry_llms_txt'] = 'LLMS.txt';

$_['entry_llms_json'] = 'LLMS.json';

$_['entry_llms_full'] = 'LLMS Full';

$_['entry_products_graph'] = 'Products Graph';

// Help
$_['help_status'] = 'Включва или изключва целия пакет ProBG AI Tools.';

$_['help_products'] = 'Добавя продуктите във всички AI фийдове.';

$_['help_categories'] = 'Добавя категориите във всички AI фийдове.';

$_['help_brands'] = 'Добавя марките във всички AI фийдове.';

$_['help_product_limit'] = '0 = всички продукти.';

$_['help_htaccess'] = 'Добавете тези правила преди основното OpenCart SEO правило.';

// URL labels
$_['text_ai_sitemap_url'] = 'AI Sitemap URL';

$_['text_llms_txt_url'] = 'LLMS.txt URL';

$_['text_llms_json_url'] = 'LLMS.json URL';

$_['text_llms_full_url'] = 'LLMS Full URL';

$_['text_products_graph_url'] = 'Products Graph URL';

// htaccess
$_['text_htaccess_rule'] = 'RewriteRule ^ai-sitemap\.xml$ index.php?route=extension/feed/probg_ai_tools [L,QSA]

RewriteRule ^llms\.txt$ index.php?route=extension/feed/probg_ai_tools/llms [L,QSA]

RewriteRule ^llms\.json$ index.php?route=extension/feed/probg_ai_tools/json [L,QSA]

RewriteRule ^llms-full\.txt$ index.php?route=extension/feed/probg_ai_tools/full [L,QSA]

RewriteRule ^products\.graph\.json$ index.php?route=extension/feed/probg_ai_tools/graph [L,QSA]';

// Error
$_['error_permission'] = 'Нямате права за промяна на ProBG AI Tools!';