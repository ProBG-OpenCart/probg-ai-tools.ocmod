<?php
class ControllerExtensionFeedProbgAiTools extends Controller {

  public function index() {
    if ((int)$this->config->get('feed_probg_ai_tools_status') !== 1) {
      $this->disabled();
      return;
    }
    $this->load->language('extension/feed/probg_ai_tools');

    $this->response->addHeader('Content-Type: application/json; charset=utf-8');

    $data = array(
      'site' => array(
        'name' => $this->cleanText($this->config->get('config_name')),
        'url'  => $this->config->get('config_url')
      ),
      'generated_at' => date('Y-m-d H:i:s')
    );

    if ($this->config->get('feed_probg_ai_tools_products')) {
      $data['products'] = $this->getProducts();
    }

    if ($this->config->get('feed_probg_ai_tools_categories')) {
      $data['categories'] = $this->getCategories();
    }

    if ($this->config->get('feed_probg_ai_tools_brands')) {
      $data['brands'] = $this->getBrands();
    }

    $this->response->setOutput(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
  }

  public function llms() {
    if ((int)$this->config->get('feed_probg_ai_tools_llms_txt') !== 1) {
      $this->disabled();
      return;
    }
    $this->load->language('extension/feed/probg_ai_tools');

    $this->response->addHeader('Content-Type: text/plain; charset=utf-8');

    $output = '# ' . $this->cleanText($this->config->get('config_name')) . "\n\n";

    $description = $this->cleanText(
      $this->config->get('feed_probg_ai_tools_site_description')
    );

    if (empty($description)) {

      $description = $this->cleanText(
        $this->config->get('config_meta_description')
      );

    }

    if ($description) {
      $output .= '> ' . $description . "\n\n";
    }

    $output .= $this->language->get('text_website') . ': ' . $this->config->get('config_url') . "\n\n";

    if ($this->config->get('feed_probg_ai_tools_categories')) {
      $output .= '## ' . $this->language->get('text_categories') . "\n\n";

      foreach ($this->getCategories() as $category) {
        $output .= '- [' . $category['name'] . '](' . $category['url'] . ')';

        if (!empty($category['description'])) {
          $output .= ': ' . $category['description'];
        }

        $output .= "\n";
      }

      $output .= "\n";
    }

    if ($this->config->get('feed_probg_ai_tools_products')) {
      $output .= '## ' . $this->language->get('text_products') . "\n\n";

      foreach ($this->getProducts() as $product) {
        $output .= '- [' . $product['name'] . '](' . $product['url'] . ')';

        if (!empty($product['description'])) {
          $output .= ': ' . $product['description'];
        }

        $output .= "\n";
      }

      $output .= "\n";
    }

    if ($this->config->get('feed_probg_ai_tools_brands')) {
      $output .= '## ' . $this->language->get('text_brands') . "\n\n";

      foreach ($this->getBrands() as $brand) {
        $output .= '- [' . $brand['name'] . '](' . $brand['url'] . ')' . "\n";
      }

      $output .= "\n";
    }

    $output .= '## ' . $this->language->get('text_ai_resources') . "\n\n";

    if ($this->config->get('feed_probg_ai_tools_llms_json')) {
      $output .= '- [' . $this->language->get('text_llms_json') . '](' . HTTPS_CATALOG . "llms.json)\n";
    }

    if ($this->config->get('feed_probg_ai_tools_llms_full')) {
      $output .= '- [' . $this->language->get('text_llms_full') . '](' . HTTPS_CATALOG . "llms-full.txt)\n";
    }

    if ($this->config->get('feed_probg_ai_tools_products_graph')) {
      $output .= '- [' . $this->language->get('text_products_graph') . '](' . HTTPS_CATALOG . "products.graph.json)': ' . $this->language->get('text_graph_description')\n";
    }

    $output .= "\n---\n' . $this->language->get('text_generated') . ': " . date('Y-m-d H:i:s');

    $this->response->setOutput($output);
  }

  public function json() {
    if ((int)$this->config->get('feed_probg_ai_tools_llms_json') !== 1) {
      $this->disabled();
      return;
    }

    $this->load->language('extension/feed/probg_ai_tools');
    $this->index();
  }

  public function full() {
    if ((int)$this->config->get('feed_probg_ai_tools_llms_full') !== 1) {
      $this->disabled();
      return;
    }
    $this->load->language('extension/feed/probg_ai_tools');

    $this->response->addHeader('Content-Type: text/plain; charset=utf-8');

    $output = "# Full AI Dataset\n\n";
    $output .= "Website: " . $this->config->get('config_url') . "\n\n";

    $output .= "## Products\n\n";

    foreach ($this->getProducts(false) as $product) {
      $output .= '- ' . $product['name'];
      $output .= ' | URL: ' . $product['url'];

      if (!empty($product['price'])) {
        $output .= ' | Price: ' . $product['price'];
      }

      if (!empty($product['model'])) {
        $output .= ' | Model: ' . $product['model'];
      }

      if (!empty($product['description'])) {
        $output .= ' | ' . $product['description'];
      }

      $output .= "\n";
    }

    $this->response->setOutput($output);
  }

  public function graph() {
    if ((int)$this->config->get('feed_probg_ai_tools_products_graph') !== 1) {
      $this->disabled();
      return;
    }
    $this->load->language('extension/feed/probg_ai_tools');

    $this->response->addHeader('Content-Type: application/json; charset=utf-8');

    $nodes = array();
    $edges = array();

    foreach ($this->getCategories() as $category) {
      $nodes[] = array(
        'id' => 'category_' . $category['id'],
        'type' => 'category',
        'name' => $category['name'],
        'url' => $category['url']
      );
    }

    foreach ($this->getBrands() as $brand) {
      $nodes[] = array(
        'id' => 'brand_' . $brand['id'],
        'type' => 'brand',
        'name' => $brand['name'],
        'url' => $brand['url']
      );
    }

    foreach ($this->getProducts(false) as $product) {
      $product_node_id = 'product_' . $product['id'];

      $nodes[] = array(
        'id' => $product_node_id,
        'type' => 'product',
        'name' => $product['name'],
        'url' => $product['url'],
        'price' => $product['price']
      );

      if (!empty($product['manufacturer_id'])) {
        $edges[] = array(
          'from' => $product_node_id,
          'to' => 'brand_' . $product['manufacturer_id'],
          'relation' => 'manufactured_by'
        );
      }
    }

    $output = array(
      'meta' => array(
        'generated_at' => date('Y-m-d H:i:s'),
        'total_nodes' => count($nodes),
        'total_edges' => count($edges)
      ),
      'nodes' => $nodes,
      'edges' => $edges
    );

    $this->response->setOutput(json_encode($output, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
  }

  private function getProducts($use_limit = true) {
    $this->load->model('catalog/product');

    $limit = (int)$this->config->get('feed_probg_ai_tools_product_limit');

    if (!$use_limit || $limit <= 0) {
      $limit = 1000000;
    }

    $products = $this->model_catalog_product->getProducts(array(
      'start' => 0,
      'limit' => $limit
    ));

    $data = array();

    foreach ($products as $product) {
      $info = $this->model_catalog_product->getProduct($product['product_id']);

      $description = '';

      if (!empty($info['meta_description'])) {
        $description = $info['meta_description'];
      } elseif (!empty($info['description'])) {
        $description = $info['description'];
      }

      $data[] = array(
        'id' => (int)$product['product_id'],
        'type' => 'product',
        'name' => $this->cleanText($product['name']),
        'url' => $this->url->link('product/product', 'product_id=' . (int)$product['product_id']),
        'description' => mb_substr($this->cleanText($description), 0, 300),
        'price' => isset($product['price']) ? $product['price'] : '',
        'model' => isset($product['model']) ? $product['model'] : '',
        'manufacturer_id' => isset($product['manufacturer_id']) ? (int)$product['manufacturer_id'] : 0
      );
    }

    return $data;
  }

  private function getCategories() {
    $this->load->model('catalog/category');

    $categories = $this->model_catalog_category->getCategories(0);

    $data = array();

    foreach ($categories as $category) {
      $info = $this->model_catalog_category->getCategory($category['category_id']);

      $data[] = array(
        'id' => (int)$category['category_id'],
        'type' => 'category',
        'name' => $this->cleanText($category['name']),
        'url' => $this->url->link('product/category', 'path=' . (int)$category['category_id']),
        'description' => !empty($info['description']) ? mb_substr($this->cleanText($info['description']), 0, 300) : ''
      );
    }

    return $data;
  }

  private function getBrands() {
    $this->load->model('catalog/manufacturer');

    $manufacturers = $this->model_catalog_manufacturer->getManufacturers();

    $data = array();

    foreach ($manufacturers as $manufacturer) {
      $data[] = array(
        'id' => (int)$manufacturer['manufacturer_id'],
        'type' => 'brand',
        'name' => $this->cleanText($manufacturer['name']),
        'url' => $this->url->link('product/manufacturer/info', 'manufacturer_id=' . (int)$manufacturer['manufacturer_id'])
      );
    }

    return $data;
  }

  private function cleanText($text) {
    $text = html_entity_decode((string)$text, ENT_QUOTES, 'UTF-8');
    $text = preg_replace('#<script(.*?)>(.*?)</script>#is', ' ', $text);
    $text = preg_replace('#<style(.*?)>(.*?)</style>#is', ' ', $text);
    $text = strip_tags($text);
    $text = preg_replace('/\s+/', ' ', $text);

    return trim($text);
  }

  private function disabled() {

    $this->load->language('extension/feed/probg_ai_tools');
    $this->response->addHeader('HTTP/1.1 410 Gone');
    $this->response->setOutput(
      $this->language->get('text_feed_disabled')
    );
  }
}